/* ***************************************
 * classConn.h
 *****************************************/


#ifndef CLASSCONN_H
#define CLASSCONN_H

#include <my_global.h>
#include <my_sys.h>
#include <mysql.h>

#include <classDraw.h>
#include <classGetchoice.h>


class classConn
{
public:
    classConn();
    virtual ~classConn();

    std::vector<std::string> menu;

    static int          qstate;
    static MYSQL_ROW    row;
    static MYSQL_RES   *res;
    static MYSQL_FIELD *field;
    static MYSQL       *mysql;
    static MYSQL* connection();
    static void printError(MYSQL *mysql, std::string message);

protected:

private:

    int *totallen;
};

#endif // CLASSCONN_H
