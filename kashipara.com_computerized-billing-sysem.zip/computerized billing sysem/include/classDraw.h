/* ***************************************
 * classDraw.h
 *****************************************/



#ifndef CLASSDRAW_H
#define CLASSDRAW_H

#include <iostream>
#include <cstdio>
#include <sys/ioctl.h>
#include <unistd.h>

class classDraw
{
public:
    classDraw();
    virtual ~classDraw();

    void gotoxy(int x, int y);
    void clrscr();
    void clrscr(int x1, int y1, int x2, int y2);
    void drawRect();

protected:

private:

    struct winsize w;

    int *totalnen;
};

#endif // CLASSDRAW_H
