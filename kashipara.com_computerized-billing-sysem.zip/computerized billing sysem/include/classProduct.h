/* ***************************************
 * classProduct.h
 *****************************************/



#ifndef CLASSPRODUCT_H
#define CLASSPRODUCT_H

#include <my_global.h>
#include <mysql/my_sys.h>
#include <mysql/mysql.h>
#include <iomanip>
#include <bits/stdc++.h>
#include <cstdlib>
#include <iostream>
#include <cstring>
#include <string>
#include <vector>
#include <cctype>
#include <sys/ioctl.h>
#include <unistd.h>
#include <X11/Xlib.h>


#include "classConn.h"
#include "classGetchoice.h"
#include "classProduct.h"
#include "classGetchar.h"
#include "classDraw.h"
#include "classValid.h"
#include "classBill.h"
#include "classSqlProcess.h"

//class classBill;
class classConn;
class classGetchar;
class classGetchoice;
class classDraw;
class classSqlProcess;
class classValid;

class classProduct
{
public:
    classProduct();
    virtual ~classProduct();
    classProduct& operator=(const classProduct& rhs);

    void showAllProduct();
    unsigned long displayProduct();
    unsigned long displayProduct(std::string header);
    void productEnter();
    classProduct * productSearch(int prdno);
    void productModify();

protected:

private:

    bool f;

    struct winsize w;

    MYSQL *mysql;
    MYSQL_RES *res;
    MYSQL_ROW row;

    classSqlProcess *sqlp;
    classDraw *draw;
    classGetchar *getc;
    classGetchoice *get;

    std::vector<std::string> productRecords;
    std::vector<int> prdids;
    std::vector<int>::iterator iter;

    std::string sql;
    std::string strrate;
    std::string strmaxpid;
    std::string strstock;
    std::string strprdid;
    std::string strproductid;
    std::string productName;
    std::string strch;
    std::string stryesno;

    unsigned long productid;
    unsigned long prdid;

    int *totallen;
    int intch;
    int i;
    int times;
    int maxpid;
    int qstate;
    int billno;
    int stock;
    int  rate;
    int len;

    char yesno;
    char ch;


};

#endif // CLASSPRODUCT_H
