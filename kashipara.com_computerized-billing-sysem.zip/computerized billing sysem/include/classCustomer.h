/* ***************************************
 * classCustomer.h
 *****************************************/



#ifndef CLASSCUSTOMER_H
#define CLASSCUSTOMER_H

#include <mysql.h>
#include <iostream>
#include <sys/ioctl.h>
#include <cstdio>
#include <cstdlib>

#include "classConn.h"
#include "classDraw.h"
#include "classGetchar.h"
#include "classSqlProcess.h"
#include "classConn.h"

class classCustomer
{
public:
    classCustomer();
    virtual ~classCustomer();

    void showCustomer();
    void deleteCustomer(int id, int x, int y);
    void addCustomer();
    void modifyCustomerRecord();

protected:

private:

    winsize w;

    std::vector<std::string> customerMenu;
    std::vector<int> idvec;
    std::vector<int>::iterator iter;

    std::string strid;
    std::string strcname;
    std::string straddress;
    std::string strmobileno;
    std::string strbillno;
    std::string sql;
    std::string strchoice;
    std::string strnameid;
    std::string strcid;

    classDraw *draw;
    classGetchar *getc;
    classGetchoice *get;
    classSqlProcess *sqlp;

    int id;
    int billno;
    int qstate;
    int choice;
    int len;
    int lines;
    int i;

    bool f;

    char escpch;

    MYSQL * mysql;
    MYSQL_RES *res;
    MYSQL_ROW row;

    int *totallen;

    unsigned long mobileno;
};

#endif // CLASSCUSTOMER_H
