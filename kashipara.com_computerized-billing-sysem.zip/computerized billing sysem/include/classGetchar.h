/* ***************************************
 * classGetchar.h
 *****************************************/




#ifndef CLASSGETCHAR_H
#define CLASSGETCHAR_H

#include <termios.h>
#include <cstdio>

static struct termios oldterm, newterm;

#include <iostream>
#include <iomanip>
#include <cstdio>
#include <termios.h>
#include <unistd.h>

class classGetchar
{
public:
    classGetchar();
    virtual ~classGetchar();
private:
    termios   oldterm;
    termios   newterm;
    char getch_(bool echo);
public:
    char getch(void);
    void initTermios(bool echo);
    void resetTermios(void);
    char getche(void);

};

#endif // CLASSGETCHAR_H
