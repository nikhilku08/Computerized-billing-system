/* ***************************************
 * classBill.h
 *****************************************/


#ifndef CLASSBILL_H
#define CLASSBILL_H

#include <mysql.h>
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <bits/stdc++.h>

#include "classConn.h"
#include "classProduct.h"
#include "classDraw.h"
#include "classSqlProcess.h"
#include "classGetchoice.h"
#include "classCustomer.h"
#include "classValid.h"

class classProduct;

struct date
{
    int yy, mm, dd;
};

struct Vprd
{

    Vprd();
    ~Vprd();

    int pid;
    std::string pname;
    int prate;
    int pquantity;
    int ptotal;

};

class classBill//: public classDraw
{
public:
    classBill();
    virtual ~classBill();

    void billing();

    std::vector<std::string> salesmenu;

    void todaySales();

    static int statbillno;

    void modifyBill();

    void viewBill();

    void delEntry();

protected:

private:

    classDraw *draw;
//    Vpid *ele;
    classSqlProcess *sqlp;
    classGetchar *getc;
    classGetchoice *get;
    classProduct *prd;
    classCustomer *customer;

    Vprd *vprd ;
    Vprd vp;

//    Date *dt;

    MYSQL *mysql;
    MYSQL_RES *res;
    MYSQL_ROW row;

    winsize w;

    bool flag;

    std::string sql;
    std::string productname;
    std::string strmemno;
    std::string strdate;
    std::string strmobileno;
    std::string strcname;
    std::string strcaddress;
    std::string cname;
    std::string strzero;
    std::string stramt;
    std::string strquantity;
    std::string strmaxid;
    std::string strstock;
    std::string strtotal;
    std::string stramount;
    std::string strprdid;
    std::string strqty;
    std::string strbillno;
    std::string strcustomerid;
    std::string strproductid;
    std::string strproductname;
    std::string strrate;
    std::string strcmd;
    std::string strid;
    std::string strvpid;

//    std::vector<Vpid> Vecbillpid;
//    std::vector<Vpid>::iterator iter;
    std::vector<std::string> cnamevec;
    std::vector<std::string>::iterator cnveciter;
    std::vector<std::string> vecBillmod;
    std::vector<std::string>::iterator strbillmoditer;
    std::vector<int> prdvec;
    std::vector<int>::iterator prditer;
    std::vector<Vprd> vprdvec;
    std::vector<Vprd>::iterator vprditer;

    std::string::iterator striter;

    char yesno;
    char escpch;
    char ch;

    int *totallen;

    int qstate;
    int productno;
    int stock;
    int rate;
    int times;
    int tlen1, tlen2;
    int quantity;
    int qty;
    int total;
    int billno;
    int maxid;
    int gamount;
    int gamountfinal;
    int i;
    int lines;
    int lines2;
    int len;
    int id;

    float gtotal;
    float netamount;
    float discount;

//    unsigned long
    unsigned long productid;
    unsigned long customerid;
    unsigned long mobileno;
    unsigned long cmobileno;
    unsigned long l;
};

#endif // CLASSBILL_H
