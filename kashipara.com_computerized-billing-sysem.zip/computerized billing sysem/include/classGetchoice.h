/* ***************************************
 * classGetchoice.h
 *****************************************/



#ifndef CLASSGETCHOICE_H
#define CLASSGETCHOICE_H

#include <vector>
#include "classConn.h"
#include "classDraw.h"
#include "classValid.h"
#include "classGetchar.h"

class classGetchoice : public classDraw, public classGetchar
{
public:
    classGetchoice();
    virtual ~classGetchoice();

    int printMenu(std::vector<std::string> menu, std::string header);
    int getChoice(std::vector<std::string> choices);

protected:

private:
    int *totallen;

    winsize w;

    int i;
    int l;
    int space;
    int choosen;

    std::vector<std::string> menu;
    std::vector<std::string>::const_iterator iter;
    std::string strch;

    MYSQL     *mysql;
    MYSQL_ROW  row;
    MYSQL_RES *res;

    classDraw *draw;

};

#endif // CLASSGETCHOICE_H
