/* ***************************************
 * classSqlProcess.h
 *****************************************/




#ifndef CLASSSQLPROCESS_H
#define CLASSSQLPROCESS_H

#include <iostream>
#include <string>
#include "classSqlProcess.h"
#include "classDraw.h"
#include "classGetchar.h"
#include "classGetchoice.h"

#include <mysql.h>
#include <cstring>

class classSqlProcess
{
public:
    classSqlProcess();
    virtual ~classSqlProcess();

    void printDashes(MYSQL_RES * resset, int offset);
    int process_result_set(MYSQL *mysql, MYSQL_RES *res, int offset, int *totallen2, int big);

protected:

private:

//    classSqlProcess *sqlp;
    classDraw *draw;
    classGetchar *getc;
    classGetchoice *get;

    bool flag;

    MYSQL *mysql;
    MYSQL_RES *res;
    MYSQL_ROW row;
    MYSQL_FIELD *field;
    int *totallen;
    int k;
    int nums;
    int i;
};

#endif // CLASSSQLPROCESS_H
