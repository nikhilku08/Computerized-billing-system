/* ***************************************
 * classValid.h
 *****************************************/




#ifndef CLASSVALID_H
#define CLASSVALID_H

#include <iostream>
#include <vector>
#include <string>

#include <mysql.h>
#include "classDraw.h"



class classValid : public classDraw
{
public:
    classValid();
    virtual ~classValid();

//    static bool dateValidity(std::string date);

    static bool namevalidity(std::string strname);

    static unsigned long intvalidity(std::string strnum);

    static void splitDate(std::string date, int &y, int &m, int &d);

    static void formDate(std::string &date, int y, int m, int d);

    static bool isValidDate(std::string date);

    static bool isLeap(int year);

protected:

private:
};

#endif // CLASSVALID_H
