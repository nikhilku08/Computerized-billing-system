/* ***************************************
 * classConn.cpp
 *****************************************/




#include "classConn.h"

    static char *opt_host = "serverora.db.net";
    static char *opt_user_name = "rahul";
    static char *opt_password = "rahul";
    static unsigned int  opt_port = 3306;
    static char *opt_socket_name = NULL;
    static char *opt_db_name = "cbs";
    static unsigned int opt_flags = 0;

classConn::classConn()
{
    //ctor

    menu.push_back("1.  Show All Products");
    menu.push_back("2.  Display Product By Product ID");
    menu.push_back("3.  Enter Product Details");
    menu.push_back("4.  View An Existing Product Records");
    menu.push_back("5.  Billing");
    menu.push_back("6.  Today's Sale");
    menu.push_back("7.  Modify Product Record");
    menu.push_back("8.  Modify Customer Record");
    menu.push_back("9.  View Customer Record" );
    menu.push_back("10. Modify Bill");
    menu.push_back("11. View Bill");
    menu.push_back("12. Delete Latest Invalid Entry");
    menu.push_back("13. Exit");

    totallen = new int;
//    draw = new classDraw;
}

    MYSQL       *classConn::mysql  = nullptr;
    int          classConn::qstate = 0;
    MYSQL_ROW    classConn::row    = 0;
    MYSQL_RES   *classConn::res    = nullptr;
    MYSQL_FIELD *classConn::field  = nullptr;

classConn::~classConn()
{
    //dtor
}

MYSQL * classConn::connection()
{

    mysql_init(mysql);

    if(mysql_library_init(0,NULL, NULL))
    {
        std::cout << "mysql lib init " << std::endl;
        exit(1);
    }
    mysql = mysql_init(mysql);
    if(mysql == NULL)
    {
        std::cout<< "mysql connector is NULL";
        //cin.get();
        exit(2);
    }

     mysql = mysql_real_connect (mysql,opt_host,opt_user_name,opt_password,opt_db_name,opt_port,opt_socket_name,opt_flags);
    if(mysql == 0)
    {
        std::cout << "mysql_real_connect returned 0 : ";
        return 0;
    }
    return mysql;
}

void classConn::printError(MYSQL *mysql, std::string message)
{
    classDraw *draw = new classDraw;
    draw->gotoxy(15, 18);
    std::cout << message;
    if(mysql != nullptr)
    {
        draw->gotoxy(15, 19);
        std::cout << "Error : " << mysql_errno(mysql) << "  " << mysql_sqlstate(mysql) << "   " << mysql_error(mysql);
    }
}
