/* ***************************************
 * classProduct.cpp
 *****************************************/



#include "classProduct.h"

using std::string;
using std::cout;
using std::cin;
using std::endl;

classProduct::classProduct()
{
    //ctor
    productRecords.push_back("Product Name : ");
    productRecords.push_back("Stock : ");
    productRecords.push_back("Rate : ");
    productRecords.push_back("ProductId : ");

    get = new classGetchoice;
    draw = new classDraw;
    sqlp = new classSqlProcess;

    getc = new classGetchar;

    totallen = new int;
}

classProduct::~classProduct()
{
    //dtor
    delete get;
    delete draw;
    delete sqlp;
    delete getc;
    delete mysql;
    delete res;
    delete draw;
    delete totallen;
}

classProduct& classProduct::operator=(const classProduct& rhs)
{
    if (this == &rhs) return *this; // handle self assignment
    //assignment operator
    return *this;
}

void classProduct::showAllProduct()
{
    int times;
    char choose;
    draw->clrscr();
    draw->drawRect();
    int l = 5;
    int qstate;
    int i = 0;
    int gtotalofstock = 0;
    draw->gotoxy(15, 5);
    char ch ;
    string strQuery;
    cout << "Welcome To Electronic Store";

    draw->gotoxy(15, 6);
    cout << "Show All Items Menu\n";

    do
    {
        gtotalofstock = 0;
        do
        {
            draw->gotoxy(2, 7);
            cout << "Enter producname -> P | Stock -> S |\n| Rate -> R | ProductID -> I : ";
            ch = getc->getche();
            draw->gotoxy(31, 8);
        }while(toupper(ch) != 'P' && toupper(ch) != 'S' && toupper(ch) != 'R' && toupper(ch) != 'I' && int(ch) != 10);


        if(toupper(ch) == 'P')
        {
            sql = "select *from tableProductRecords order by productname asc;";
        }
        else if(toupper(ch)  == 'S')
        {
            sql = "select *from tableProductRecords order by Stock asc;";
        }
        else if(toupper(ch) == 'R')
        {
            sql = "select *from tableProductRecords order by Rate asc;";
        }
        else if( toupper(ch) == 'I')
        {
            sql = "select *from tableProductRecords order by ProductId asc;";
        }

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            i = sqlp->process_result_set(mysql, res, 11, totallen, 0);
        }
        else
        {
            cout << " error : " << "  "<< mysql_error(mysql) << "  " << endl;
        }

        sql = "select rate, stock from tableProductRecords";
        mysql->reconnect = true;
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());

        if(!qstate)
        {
            res = mysql_store_result(mysql);
            while((row = mysql_fetch_row(res)) != nullptr)
            {
                gtotalofstock += std::stoi(row[0]) * std::stoi(row[1]);
            }
            draw->gotoxy(2, 9);
            cout << "Grand Total of Stock Rate : "<< gtotalofstock << " INR ";
        }
        draw->gotoxy(31, 8);
    }while(int(ch) != 10);
}

unsigned long classProduct::displayProduct(string header)
{
    unsigned long l = 0, l2 = 0;
    int times;
    int intch;
    int length = 0;
    string prdin = "";
    string prd2 = "";
    string sql;
    string strbillno;
    int x1 = 24;
    unsigned long prdid;
    int lines;
    char ch;
    char escpch;

    bool flag = false;

    mysql = classConn::connection();
    mysql->reconnect = true;

    classDraw *draw = new classDraw;

    prdin.clear();

    do
    {
        draw->clrscr();
        draw->drawRect();

        get->printMenu(productRecords, header);
        draw->gotoxy(2, 5);
        cout << "Enter Product Name : ";
        draw->gotoxy(x1, 5);
        cout << prdin;
        ch = getc->getche();
        intch = int(ch);
        string prdsearch;

//        if(ch == 'q')
//        {
//            return 0;
//        }

        if(intch == 27)
        {
            return 0;
        }
        else if(intch == 127 && prdin.length() > 0)
        {
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            draw->gotoxy(x1, 5);
            for(int x = x1; x < w.ws_col -1; x++)
            {
                cout << " ";
            }
            prdin= prdin.substr(0, prdin.length() - 1);
        }
        else if(intch == 10 && prdin.length() == 0)
        {
            prdid = 0;
            return 0;
        }
        else if(intch == 9)
        {
            sql = "select productid from tableProductRecords where productname like '"+prdin+"%' order by productname;";
            mysql = classConn::connection();
            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->clrscr(2, 10, w.ws_col - 1, w.ws_row - 1);
                draw->gotoxy(22, 5);

                res = mysql_store_result(mysql);
                prdids.clear();
                while((row = mysql_fetch_row(res)) != nullptr)
                {
                    prdids.push_back(atoi(row[0]));
                }
                if(prdids.empty())
                {
                    prdid = 0;
                    return 0;
                }
                iter = prdids.begin();
                while((int (escpch = getc->getch())) == 9 && iter != prdids.end() )
                {
                    strprdid = std::to_string(*iter++);
                    sql = "select *from  tableProductRecords where productname like '"+prdin+"%' order by productname;";
                    qstate = mysql_query(mysql, sql.c_str());
                    if(!qstate)
                    {
                        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                        draw->clrscr(1, 10, w.ws_col, w.ws_row);
                        draw->drawRect();
                        res = mysql_store_result(mysql);
                        lines = sqlp->process_result_set(mysql, res, 10, totallen, 0);
                        len = *totallen;

//                        draw->gotoxy(60, 41);
//                        cout << "len = " << len;
//                        getc->getch();
                    }
                    mysql = classConn::connection();
                    sql = "select * from tableProductRecords where productid = '"+strprdid+"';";
//                    draw->gotoxy(10 + len + 30, 35);
//
//                    cout << "after sql * product len : " << len;
//                    getc->getch();

                    qstate = mysql_query(mysql, sql.c_str());
                    if(!qstate)
                    {
                        res = mysql_store_result(mysql);
                        if((row = mysql_fetch_row(res)) != nullptr)
                        {
                            draw->gotoxy(x1, 5);
                            for(int y = x1; y < len -4; y++)
                            {
                                cout << " ";
                            }
                            draw->gotoxy(x1, 5);
                            prd2 = row[0];
                            cout << row[0];
//                            draw->gotoxy(60, 40);
//                            cout << "len : " << len << "len -4 " << len -4;
//                            getc->getch();

                            draw->gotoxy(x1,6);
                            for(int y = x1; y < len-4; y++)
                            {
                                cout << " ";
                            }
                            draw->gotoxy(x1, 6);
                            cout << atoi(row[1]);

                            draw->gotoxy(x1, 7);
                            for(int y = x1; y < len-4; y++)
                            {
                                cout << " ";
                            }
                            draw->gotoxy(x1, 7);
                            cout << atoi(row[2]);

                            draw->gotoxy(x1, 8);
                            for(int y = x1; y < len-4; y++)
                            {
                                cout << " ";
                            }
                            draw->gotoxy(x1, 8);

                            prdid = atol(row[3]);
                            cout << prdid;
                            draw->gotoxy(x1 + prdin.length() , 5);
                        }
                    }
                    else
                    {
                        draw->gotoxy(1, 11);
                        cout << "error : " << mysql_error(mysql);
                        cin.get();
                    }
                    if(iter == prdids.end())
                    {
                        iter = prdids.begin();
                    }
                    draw->gotoxy(2, 9);
                    for(int i = x1; i < length + 7; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(2,9);
                    cout <<"search string : " << prdin;
                    draw->gotoxy(x1, 5);
                    mysql_free_result(res);
                    mysql_close(mysql);
                }
            }
            prdin  = prd2;
        }
        else
        {
            prdin += ch;
        }
    }while(intch != 10);
    return prdid;
}


unsigned long classProduct::displayProduct()
{
    mysql = classConn::connection();
    strprdid.clear();

    do
    {
        draw->clrscr();
        do
        {
            draw->drawRect();
            get->gotoxy(25, 3);
            cout << "Search By Product ID";
            get->gotoxy(23, 4);
            cout << "------------------------";

            get->gotoxy(11, 5);
            cout << "Enter Product ID : ";

            get->gotoxy(31, 5);
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

            for(i = 31; i < w.ws_col - 1; i++)
            {
                cout << " ";
            }
            draw->gotoxy(31, 5);
            cout << strprdid;

            ch = getc->getche();
            intch = int(ch);
            if(intch == 127 && strprdid.length() > 0)
            {
                draw->gotoxy(31, 5);
                for(int x = 31; x < w.ws_col -1; x++)
                {
                    cout << " ";
                }
                strprdid = strprdid.substr(0, strprdid.length() - 1);
                draw->gotoxy(31, 5);
                cout << strprdid;
            }
            else
            {
                strprdid += ch;
            }
            prdid = classValid::intvalidity(strprdid);

            if(prdid == 0 && !strprdid.empty() && intch != 10)
            {
                draw->gotoxy(31, 5);
                cout << "Invalid product id";
                getc->getch();
                strprdid.clear();
            }
        }
        while(prdid == 0 && intch != 10);
        if(intch != 10)
        {
            sql = "select * from tableProductRecords where productid like '%"+strprdid+"%';";
            qstate = mysql_query(mysql, sql.c_str());

            if(!qstate)
            {
                draw->drawRect();
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

                draw->gotoxy(1, 11);
                res = mysql_store_result(mysql);
                sqlp->process_result_set(mysql, res, 10, totallen, 0);
                getc->getch();
            }
            else
            {
                draw->gotoxy(10, 20);
                strprdid.clear();
                cout << "Error in product search by id : " << mysql_error(mysql);
                getc->getch();
            }
        }
    }
    while(intch != 10);

    return prdid;

}

void classProduct::productEnter()
{
    int x1 = 18;
    draw->clrscr();
    draw->drawRect();

    mysql = classConn::connection();
    mysql->reconnect = true;

    get->printMenu(productRecords, "Product Enter");
    draw->gotoxy(x1, 5);

    productName.clear();
    do
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

        draw->gotoxy(x1, 5);
        for(i = 30; i < w.ws_col-1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(x1, 5);

        getline(cin, productName);
        if(!productName.compare("q"))
        {
            return;
        }

    }while(productName.empty());

    do
    {
        draw->gotoxy(x1, 6);
        for( i = x1; i < w.ws_col-1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(x1, 6);
        getline(cin, strstock);
        if(!strstock.compare("q"))
        {
            return;
        }
        stock = classValid::intvalidity(strstock);
        if(stock == 0)
        {
            draw->gotoxy(x1, 6);
            cout << "invalid stock";
            getc->getch();
        }
    }while(stock == 0);

    do
    {
        draw->gotoxy(x1, 7);
        for(i = x1; i < w.ws_col-1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(x1, 7);
        getline(cin, strrate);
        if(!strrate.compare("q"))
        {
            return;
        }
        rate = classValid::intvalidity(strrate);
        if(rate == 0)
        {
            draw->gotoxy(x1, 7);
            cout << "invalid rate";
            getc->getch();
        }
    }while(rate == 0);

    sql = "select max(productid) from tableProductRecords";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            draw->gotoxy(x1, 8);
            if(row[0] == nullptr)
            {
                maxpid = 0;
            }
            else
            {
                maxpid = atoi(row[0]);
            }
            strmaxpid = std::to_string(++maxpid);
        }
    }

    draw->gotoxy(x1, 8);
    cout << strmaxpid;

    draw->gotoxy(15, 10);
    cout << "Really want to save data (y/n) : ";
    do
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->gotoxy(46, 10);
        for(i = 46; i< w.ws_col-1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(46, 10);
        getline(cin, stryesno);
   }while(stryesno.compare("Y") && stryesno.compare("y") && stryesno.compare("N") &&  stryesno.compare("n"));
//   }while(toupper(yesno) != 'Y' && toupper(yesno) != 'N');

    if(!stryesno.compare("Y") || !stryesno.compare("y"))
    {
        sql = "insert into tableProductRecords values('"+productName+"','"+strstock+"','"+
               strrate+"','"+strmaxpid+"');";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(15, 11);
            cout << "Data inserted successfully";
            getc->getch();
        }
        else
        {
            draw->gotoxy(2, 11);
            cout << "Error in insert into tableProductRecords in product enter : " << mysql_error(mysql);
            getc->getch();
            return;
        }
    }
    do
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->gotoxy(15, 12);
        for(int i = 42; i < w.ws_col-1; i++)
        {
            cout << " ";
        }

        draw->gotoxy(15, 12);
        cout << "Do you want to enter more records : ";
        cin.get(yesno);
    }while(toupper(yesno) != 'Y' && toupper(yesno) != 'N');
    if(toupper(yesno) == 'Y')
    {
        productEnter();
    }
    else
    {
        return;
    }
}

classProduct* classProduct::productSearch(int  prdno)
{
    mysql = classConn::connection();

    std::string strprdno = std::to_string(prdno);
    sql = "select *from tableProductRecords where productid = '"+strprdno+"';";

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        sqlp->process_result_set(mysql, res, 10, totallen, 0);
        getc->getch();

        if((row = mysql_fetch_row(res)) != nullptr)
        {
            this->productName = row[0];
            this->stock = atoi(row[1]);
            this->rate = atoi(row[2]);
            this->productid = atol(row[3]);
        }
    }
    return this;
}


void classProduct::productModify()
{
    long l = displayProduct("PRODUCT MODIFY");

    string strchoice;
    string strprdno = std::to_string(l);

    if(l == 0)
    {
        return;
    }

    int choice;

    sql = "select *from tableProductRecords where productid = '"+strprdno+"';";
    mysql = classConn::connection();
    mysql->reconnect = true;

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->clrscr(1, 12, w.ws_col -1, w.ws_row -1);
        draw->drawRect();
        res = mysql_store_result(mysql);
        draw->gotoxy(1, 10);
        sqlp->process_result_set(mysql, res, 10, totallen, 0);

        do
        {
            draw->gotoxy(2, 15);
            cout << "Which data you want to modify (1 .. 4) d for delete, q for return : ";
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            for(i = 70; i < w.ws_col -1; i++)
            {
                cout << " ";
            }
            draw->gotoxy(70, 15);
            getline(cin, strchoice);
            choice = classValid::intvalidity(strchoice);
            if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && strchoice.compare("q") && strchoice.compare("d"))
            {
                draw->gotoxy(70, 15);
                cout << "invalid input ";
                getc->getch();
            }
        }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && strchoice.compare("q") && strchoice.compare("d"));

        if(!strchoice.compare("q"))
        {
            return;
        }

        if(!strchoice.compare("d"))
        {
            mysql = classConn::connection();
            sql = "delete from tableProductRecords where productid = '"+strprdno+"';";
            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                draw->gotoxy(2, 16);
                cout << "product data deleted of productid = " << strprdno;
                getc->getch();
                return;
            }
        }

        int x = 24;
        draw->gotoxy(x, 5 + --choice);
        switch(choice)
        {
        case 0:
            {
                do
                {
                    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                    draw->gotoxy(x, 5 + choice);
                    for(i = 23; i < w.ws_col -1 ; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(x, 5 + choice);
                    getline(cin, productName);
                    f = classValid::namevalidity(productName);
                    if(f == false)
                    {
                        productName.empty();
                    }
                }while(productName.empty());
                sql = "update tableProductRecords set productname = '"+productName+"' where productid = '"+strprdno+"';";
            }
            break;
        case 1:
            {
                do
                {

                    draw->gotoxy(x, 5 + choice);
                    for(int i = 23; i < w.ws_col; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(x, 5 + choice);
                    getline(cin, strstock);
                    stock = classValid::intvalidity(strstock);
                    if(stock == 0)
                    {
                        strstock.clear();
                    }
                }while(strstock.empty());
                sql = "update tableProductRecords set stock = '"+strstock+"' where productid = '"+strprdno+"';";
            }
            break;
        case 2:
            {

                 do
                {
                    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                    draw->gotoxy(x, 5 + choice);
                    for(int i = 23; i < w.ws_col; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(x, 5 + choice);
                    getline(cin, strrate);
                    stock = classValid::intvalidity(strrate);
                    if(stock == 0)
                    {
                        strrate.clear();
                    }

                }while(strrate.empty());
                sql = "update tableProductRecords set rate = '"+strrate+"' where productid = '"+strprdno+"';";
            }
            break;

        case 3:
            {
               do
                {
                    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                    draw->gotoxy(x, 5 + choice);
                    for(int i = 23; i < w.ws_col; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(x, 5 + choice);
                    getline(cin, strproductid);
                    productid = classValid::intvalidity(strproductid);
                    if(productid == 0)
                    {
                        strproductid.clear();
                    }

                }while(strproductid.empty());
                sql = "update tableProductRecords set productid = '"+strproductid+"' where productid = '"+strprdno+"';";
                strprdno = strproductid;
            }
            break;
        default:
            draw->gotoxy(1, 16);
            cout << "please enter valid option ";
            sql.clear();
        }

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());

        if(!qstate)
        {
            draw->gotoxy(5, 18);
            cout << "data modified successfuly and modified data is : ";
            sql = "select * from tableProductRecords where productid = '"+strprdno+"';";

            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->clrscr(1, 21, w.ws_col -1, w.ws_row -1 );
                draw->drawRect();
                res = mysql_store_result(mysql);
                draw->gotoxy(1, 21);
                sqlp->process_result_set(mysql, res, 21, totallen, 0);
            }
        }
        else
        {
            draw->gotoxy(5, 19);
            cout << "Error " << mysql_error(mysql);
        }
    }
    else
    {
        draw->gotoxy(5, 15);
        cout << "Error in else of productModify : " << mysql_error(mysql);
    }
    draw->gotoxy(5, 19);

    do
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->gotoxy(5, 19);
        for(int i = 5; i < w.ws_col-1; i++)
        {
            cout << " ";
        }

        draw->gotoxy(5, 19);
        cout << "Want to modify more : ";
        cin.get(yesno);
        draw->gotoxy(5, 19);
    }
    while(toupper(yesno) != 'Y' && toupper(yesno) != 'N');

    if( toupper(yesno) == 'Y')
    {
        l = displayProduct();
        productModify();
    }
    else
    {
        return;
    }
}























