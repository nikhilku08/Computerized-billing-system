/* ***************************************
 *  classCustomer.cpp
 *****************************************/



#include "classCustomer.h"
#include <bits/stdc++.h>

using std::cout;
using std::cin;
using std::string;

classCustomer::classCustomer()
{
    //ctor
    draw = new classDraw;
    mysql = new MYSQL;
    getc = new  classGetchar;
    get = new classGetchoice;
    sqlp = new classSqlProcess;

    customerMenu.push_back("ID : ");
    customerMenu.push_back("Customer Name : ");
    customerMenu.push_back("Contact Address : ");
    customerMenu.push_back("Mobile No. : ");
    customerMenu.push_back("Bill No : ");

    totallen = new int;
}

classCustomer::~classCustomer()
{
    //dtor
    delete mysql;
    delete draw;
    delete getc;
    delete get;
    delete sqlp;
    delete totallen;
}

void classCustomer:: showCustomer()
{
    draw->clrscr();
    draw->drawRect();

    int const x1 = 20;

    int l = get->printMenu(customerMenu, "Customer Details");

    draw->gotoxy(20, 6);
    do
    {
        draw->gotoxy(20, 6);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(int i = 20; i < w.ws_col - 1; i++)
        {
            std::cout << " ";
        }
        draw->gotoxy(20, 6);
        getline(std::cin, strcname);
        bool f = classValid::namevalidity(strcname);
        if(f == false)
        {
            draw->gotoxy(20, 6);
            std::cout << "Enter valid name";
            strcname.clear();
            getc->getch();
        }

        if(!strcname.compare("q"))
        {
             return;
        }
    }while(strcname.empty());

    sql = "select *from tableCustomers where customername like '%"+strcname+"%';";

    mysql = classConn::connection();
    mysql->reconnect = true;

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
//        draw->gotoxy(1, 10);
        lines = sqlp->process_result_set(mysql, res, 14, totallen, 0);
        len = *totallen;
        mysql_free_result(res);
    }
    getc->getch();
}

void classCustomer::deleteCustomer(int id, int x, int y)
{
    std::string stgrid = std::to_string(id);

    sql = "delete from tableCustomers where id = '"+strid+"';";

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        draw->gotoxy(x, y);
        std::cout << "customer deleted having id : " << id;
    }
    getc->getch();
}

void classCustomer::addCustomer()
{

}

void classCustomer::modifyCustomerRecord()
{
    draw->clrscr();
    draw->drawRect();

    int const x1 = 20;

    int l = get->printMenu(customerMenu, "Modify Customer Details");

    draw->gotoxy(20, 6);
    do
    {
        draw->gotoxy(20, 6);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(int i = 20; i < w.ws_col - 1; i++)
        {
            std::cout << " ";
        }
        draw->gotoxy(20, 6);
        getline(std::cin, strcname);
        bool f = classValid::namevalidity(strcname);
        if(f == false)
        {
            draw->gotoxy(20, 6);
            std::cout << "Enter valid name";
            strcname.clear();
            getc->getch();
        }

        if(!strcname.compare("q"))
        {
             return;
        }
    }while(strcname.empty());

    sql = "select *from tableCustomers where customername like '%"+strcname+"%';";

    mysql = classConn::connection();
    mysql->reconnect = true;

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
//        draw->gotoxy(1, 10);
        lines = sqlp->process_result_set(mysql, res, 14, totallen, 0);
        len = *totallen;
        mysql_free_result(res);
    }

    sql = "select id from tableCustomers where customername like '%"+strcname+"%' order by id;";

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {

        idvec.clear();
        res = mysql_store_result(mysql);
        while((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                idvec.push_back(std::stoi(row[0]));
            }
        }
        if(idvec.empty())
        {
            draw->gotoxy(2, 10);
            cout << "Customer does not exist";
            getc->getch();
            return;
        }

        draw->gotoxy(x1, 5);

        for(iter = idvec.begin();; iter++)
        {
            escpch = getc->getch();

            if((int(escpch))  == 9)
            {
                strnameid = std::to_string(*iter);
                draw->gotoxy(2,10);
                cout <<"search string : ";
                draw->gotoxy(18, 10);
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                for(int i = x1; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(18, 10);
                cout << strnameid;
                mysql = classConn::connection();
                sql = "select * from tableCustomers where id = '"+strnameid+"';";
                qstate = mysql_query(mysql, sql.c_str());
                if(!qstate)
                {
                    res = mysql_store_result(mysql);
                    if((row = mysql_fetch_row(res)) != nullptr)
                    {
                        draw->gotoxy(x1, 5);
                        for(int y = x1; y < len -2; y++)
                        {
                            cout << " ";
                        }
                        draw->gotoxy(x1, 5);
                        cout << row[0];

                        draw->gotoxy(x1, 6);
                        for(int y = x1; y < len -2; y++)
                        {
                            cout << " ";
                        }
                        draw->gotoxy(x1, 6);
                        cout << row[1];

                        draw->gotoxy(x1, 7);
                        for(int y = x1; y < len -2; y++)
                        {
                            cout << " ";
                        }
                        draw->gotoxy(x1, 7);
                        cout << row[2];

                        draw->gotoxy(x1, 8);
                        for(int y = x1; y < len -2; y++)
                        {
                            cout << " ";
                        }
                        draw->gotoxy(x1, 8);
                        cout << row[3];

                        draw->gotoxy(x1, 9);
                        for(int y = x1; y < len -2; y++)
                        {
                            cout << " ";
                        }
                        draw->gotoxy(x1, 9);
                        cout << row[4];
                    }
//                    mysql_free_result(res);
                }
                else
                {
                    draw->gotoxy(1, lines + 18);
                    cout << "error in tab : " << mysql_error(mysql);
                    getc->getch();
                }
            }
            else if(int(escpch) == 10)
            {
                iter--;
                id = *iter;
                strnameid = std::to_string(id);
                break;
            }
            if(iter == idvec.end())
            {
                iter = idvec.begin();
                iter--;
            }
            mysql_free_result(res);
        }
    }
    else
    {
       draw->gotoxy(2, 11);
       cout << "Error in else of customername like : " << mysql_error(mysql);
       getc->getch();
    }

    do
    {
        draw->gotoxy(2, 12);
        cout << "Which data you want to modify (1 .. 5) d for delete, q for return : ";
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->gotoxy(70, 12);
        for(int i = 70; i < w.ws_col -1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(70, 12);
        getline(cin, strchoice);
        choice = classValid::intvalidity(strchoice);
        if(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && strchoice.compare("q") && strchoice.compare("d"))
        {
            draw->gotoxy(70, 12);
            cout << "Invalid input";
            getc->getch();
        }
    }while(choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 5 && strchoice.compare("q") && strchoice.compare("d"));

    if(!strchoice.compare("d"))
    {
        mysql = classConn::connection();
        strid = std::to_string(id);
        sql = "delete from tableCustomers where id = '"+strid+"';";
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(2, 13);
            cout << "Customer data deleted of id = " << id;
            getc->getch();
            return;
        }
    }
    else if(!strchoice.compare("q"))
    {
        return;
    }

    draw->gotoxy(x1, 5 + --choice);
    switch(choice)
    {
    case 0:
        {
            do
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x1, 5 + choice);
                for(i = x1; i < w.ws_col -1 ; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x1, 5 + choice);
                getline(cin, strid);

                if(!strid.compare("q"))
                {
                    return;
                }

                f = classValid::intvalidity(strid);
                if(f == false)
                {
                    strid.clear();
                }
                if(!strid.empty())
                {
                    sql = "select customername from tableCustomers where id = '"+strid+"';";
                    mysql = classConn::connection();
                    qstate = mysql_query(mysql, sql.c_str());
                    if(!qstate)
                    {
                        res = mysql_store_result(mysql);
                        if((row = mysql_fetch_row(res))!= nullptr)
                        {
                            if(row[0] != nullptr)
                            {
                                draw->gotoxy(x1, 5 + choice);
                                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                                for(int i= x1; i < w.ws_col - 1; i++)
                                {
                                    cout << " ";
                                }
                                draw->gotoxy(x1, 5 + choice);
                                cout << "ID already exists, please re-enter id";
                                strid.clear();
                                getc->getch();
                            }
                        }
                        mysql_free_result(res);
                    }
                }
            }while(strid.empty());
            sql = "update tableCustomers set id = '"+strid+"' where id = '"+strnameid+"';";
            strnameid = strid;
        }
        break;
    case 1:
        {
            do
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x1, 5 + choice);
                for(i = x1; i < w.ws_col -1 ; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x1, 5 + choice);
                getline(cin, strcname);
                if(!strcname.compare("q"))
                {
                    return;
                }
                f = classValid::namevalidity(strcname);
                if(f == false)
                {
                    strcname.clear();
                }
            }while(strcname.empty());
            sql = "update tableCustomers set customername = '"+strcname+"' where id = '"+strnameid+"';";
        }
        break;
    case 2:
        {
            do
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x1, 5 + choice);
                for(i = x1; i < w.ws_col -1 ; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x1, 5 + choice);
                getline(cin, straddress);
                if(!straddress.compare("q"))
                {
                    return;
                }
            }while(straddress.empty());
            sql = "update tableCustomers set contactaddress = '"+straddress+"' where id = '"+strnameid+"';";
        }
        break;
    case 3:
        {
            do
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x1, 5 + choice);
                for(i = x1; i < w.ws_col -1 ; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x1, 5 + choice);
                getline(cin, strmobileno);
                if(!strmobileno.compare("q"))
                {
                    return;
                }
                f = classValid::intvalidity(strmobileno);
                if(f == false)
                {
                    strmobileno.clear();
                }
            }while(strmobileno.empty());
            sql = "update tableCustomers set mobileno = '"+strmobileno+"' where id = '"+strnameid+"';";
        }
        break;
    case 4:
        {
            do
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x1, 5 + choice);
                for(i = x1; i < w.ws_col -1 ; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x1, 5 + choice);
                getline(cin, strbillno);
                if(!strbillno.compare("q"))
                {
                    return;
                }
                f = classValid::intvalidity(strbillno);
                if(f == false)
                {
                    strbillno.clear();
                }
            }while(strbillno.empty());
            sql = "update tableCustomers set billno = '"+strbillno+"' where id = '"+strnameid+"';";
        }
        break;
    default:
        {
            draw->gotoxy(2, lines + 20);
            cout << "Please enter valid choice";
            getc->getch();
        }
    }

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        if(choice >= 0 && choice < 5)
        {
            draw->gotoxy(2, lines + 20);
            cout << "data successfully updated";
            getc->getch();
        }
        else
        {
            draw->gotoxy(2, lines + 20);
            cout << "data updation failed incorrect choice : " << choice;
            getc->getch();
        }
    }
}

























