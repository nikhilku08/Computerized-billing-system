/* ***************************************
 *  classDraw.cpp
 *****************************************/




#include "classDraw.h"

using std::cout;

classDraw::classDraw()
{
    //ctor
    totalnen = new int;
}

classDraw::~classDraw()
{
    //dtor
    delete totalnen;
}

void classDraw::gotoxy(int x, int y)
{
    printf("%c[%d;%df", 0x1B, y, x);
}

void classDraw::clrscr()
{
    gotoxy(0, 0);

    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
    for(int x = 0; x < w.ws_row; x++)
    {
        for(int y = 0; y < w.ws_col; y++)
        {
            cout << " ";
        }
    }
    gotoxy(0, 0);
}

void classDraw::drawRect()
{
    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
    for(int i = 0; i <= w.ws_col; i++)
    {
        gotoxy(i, 1);
        cout << "-";
        gotoxy(i, w.ws_row);
        cout << "-";
    }
    for(int j = 0; j < w.ws_row; j++)
    {
        gotoxy(1, j);
        cout <<"|";
        gotoxy(w.ws_col, j);
        cout << "|";
    }
    gotoxy(0, 0);
}

void classDraw::clrscr(int x1, int y1, int x2, int y2)
{
    gotoxy(x1, y1);

    for(int x = x1; x <= x2; x++)
    {
        for(int y = y1; y <= y2; y++)
        {
            gotoxy(x, y);
            cout << " ";
        }
    }
    gotoxy(x1, y1);
}
