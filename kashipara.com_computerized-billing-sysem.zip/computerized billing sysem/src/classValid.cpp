/* ***************************************
 * classValid.cpp
 *****************************************/




#include "classValid.h"

using std::string;

classValid::classValid()
{
    //ctor
}

classValid::~classValid()
{
    //dtor
}

unsigned long classValid::intvalidity(string lnum)
{
    unsigned long num = 0;
    int i = 0;
    char ch_num = 0;
    std::string::iterator iter;
    if(lnum.length() == 0)
    {
        return 0;
    }

    for(iter = lnum.begin(); iter != lnum.end(); iter++)
    {
        ch_num = *iter;
        i = ch_num - 48;
        if(i >= 0 && i<= 9)
        {
            num = num * 10 + i;
        }
        else
        {
            return 0;
        }
    }
    return num;
}

bool classValid::namevalidity(string strname)
{
    std::string::iterator iter;
    char ch;
    for(iter = strname.begin(); iter != strname.end(); iter++)
    {
        ch = char(*iter);
        if( (ch < 'A' || ch > 'Z') && (ch < 'a' || ch > 'z') && ch != ' ')
        {
            return false;
        }
    }
    return true;
}

void classValid::splitDate(string date, int &y, int &m, int &d)
{
    std::string yy = date.substr(0, 4);
    std::string mm = date.substr(5, 2);
    std::string dd = date.substr(8, 2);

    y = std::stoi(yy);
    m = std::stoi(mm);
    d = std::stoi(dd);
}

void classValid::formDate(string &date, int y, int m, int d)
{
    string strdt[9] = {"01", "02", "03", "04", "05", "06", "07", "08", "09"};

    if(y < 1900 || y > 2100)
    {
        return;
    }
    else
    {
        date += std::to_string(y);
    }

    date += "/";
    if(m < 10)
    {
         date += strdt[m-1];
    }
    else if( m > 9 && m< 13)
    {
        date += std::to_string(m);
    }

    date += "/";

    if(d < 10 )
    {
        date = strdt[d - 1];

    }
    else if(d > 9 && d < 32)
    {
        date += std::to_string(d);
    }
}

bool classValid::isValidDate(string date)
{
    int y, m, d ;

    if( (date.compare(4, 1, "/", 1) != 0 && date.compare(4, 1, "-", 1) != 0) || (date.compare(7, 1, "/", 1) != 0 && date.compare(7, 1, "-", 1) != 0)|| date.length() != 10)
    {
        return false;
    }
    splitDate(date, y, m, d);

    if(y < 1900 || y > 2100)
    {
        return false;
    }

    if(d == 0 || m == 0 || y == 0)
    {
        return false;
    }
    if(d < 1 || d > 31 || m < 1 || m >12)
    {
        return false;
    }
    if( m == 2)
    {
        if(d == 30 || d == 31 || (d == 29 && isLeap(y)))
        {
            return false;
        }
    }
    else if (m == 4 || m == 6 || m == 9 || m == 11)
    {
        if(d == 31)
        {
            return false;
        }
    }
    return true;
}

bool classValid::isLeap(int y)
{
    if((y % 100 != 0 && y % 4 == 0) || y % 400  == 0)
    {
        return true;
    }
    return false;
}





















