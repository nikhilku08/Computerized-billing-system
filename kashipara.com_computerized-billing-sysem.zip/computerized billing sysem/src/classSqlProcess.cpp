/* ***************************************
 *  classSqlProcess.cpp
 *****************************************/



#include "classSqlProcess.h"

using std::cout;

classSqlProcess::classSqlProcess()
{
    //ctor
    flag = true;
    field = new MYSQL_FIELD;
    totallen = new int;
    draw = new classDraw;
    get = new classGetchoice;
    getc = new classGetchar;
}

classSqlProcess::~classSqlProcess()
{
    //dtor
    delete field;
    delete totallen;
    delete draw;
}

void classSqlProcess::printDashes(MYSQL_RES *res, int offset)
{
    unsigned int i, j, k;
//    MYSQL_FIELD *fie

    mysql_field_seek(res, 0);

    cout << "+";
    int numf = mysql_num_fields(res);
    for(int i = 0; i < numf; i++)
    {
        field = mysql_fetch_field(res);
        for(k = offset; k < field->max_length + offset; k++)
        {
            cout << "-";
        }
        cout << "+";
    }
}

int classSqlProcess::process_result_set(MYSQL *mysql, MYSQL_RES * res, int offset, int *totallen, int big)
{
    unsigned int columnLen;
    unsigned int i;
    int offset1 = 1;
    int totallen2 = 0;
    int tlen = 0;
    int times = 0;
    int j = 0;
    int l = 0;
    int intlines = 0;
    int intl = 0;
    int k = offset;
    mysql_field_seek(res, 0);

    struct winsize w;
    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

    nums = mysql_num_fields(res);
    for(int i = 0; i < nums; i++)
    {
        field = mysql_fetch_field(res);
        columnLen = strlen(field->name);
        if(columnLen < field->max_length)
        {
            columnLen = field->max_length;
        }
        if(columnLen < 4 && !(IS_NOT_NULL(field->flags)))
        {
            columnLen = 4;
        }
        field->max_length = columnLen;
        totallen2 = tlen += columnLen;
    }
//    k = 9;
    k = offset;
    draw->gotoxy(1, k);
    printDashes(res, 0);
    draw->gotoxy(1, ++k);
    cout << "|";
    mysql_field_seek(res, 0);

    for(i = 0; i < nums; i++)
    {
        field = mysql_fetch_field(res);
        cout << std::setw(field->max_length) << field->name << "|";
    }
    draw->gotoxy(1, ++k);
    printDashes(res, 0);

    while((row = mysql_fetch_row(res)) != nullptr && k < w.ws_row - 1)
    {
        draw->gotoxy(l, ++k);
        mysql_field_seek(res, 0);
        cout << "|";
        for(i = 0; i < nums; i++)
        {
            field = mysql_fetch_field(res);
            if(row[i] == nullptr)
            {
                cout << std::setw(field->max_length) << "NULL" << "|";
            }
            else
            {
                cout << std::setw(field->max_length) << row[i] << "|";
            }
        }
        if( k == w.ws_row -1)
        {
            times++;
            k = 2;
//            l = (totallen2 + nums) * times + 2;
            if(big > totallen2)
            {
                l = (totallen2 + nums + 4) * times + (big - totallen2);
            }
            else
            {
                l = (totallen2 + nums + 4) * times;
            }

            draw->gotoxy(l, k);
            printDashes(res, l);
        }
    }
    if(row == nullptr)
    {
        draw->gotoxy(l, ++k);
        printDashes(res, l);
    }

    if(l == 0)
    {
        if(big > totallen2)
        {
            *totallen = totallen2 + nums + 4  + (big - totallen2);

        }
        else
        {
            *totallen = totallen2 + nums + 4;
        }
    }
    else
    {
        if(big > totallen2)
        {
            *totallen = l + 4 + (big - totallen2);
        }
        else
        {
            *totallen = l + 4;
        }

//        draw->gotoxy(50, 50);
//        cout << "totallen2 : " << totallen2 << " " << "*totallen : " << *totallen << " " << "l : " << l << "  "
//             << " big : " << big;
//        getc->getch();
    }

    int l2 = mysql_num_rows(res);
    return l2;
}







































