/* ***************************************
 * classGetchar.cpp
 *****************************************/



#include "classGetchar.h"

classGetchar::classGetchar()
{
    //ctor
}

classGetchar::~classGetchar()
{
    //dtor
}

void classGetchar::initTermios(bool echo)
{
   tcgetattr(0, &oldterm); //grab old terminal i/o settings
  newterm = oldterm; //make new settings same as old settings
  newterm.c_lflag &= ~ICANON; //disable buffered i/o
  newterm.c_lflag &= echo ? ECHO : ~ECHO; //set echo mode
  tcsetattr(0, TCSANOW, &newterm); //apply terminal io settings
}

void classGetchar::resetTermios()
{
    tcsetattr(0, TCSANOW, &oldterm);
}

char classGetchar::getch_(bool echo)
{
    char ch;
    initTermios(echo);
    ch = getchar();
    resetTermios();
    return ch;
}

char classGetchar::getch()
{
    return getch_(false);
}

char classGetchar::getche()
{
    return getch_(true);
}
