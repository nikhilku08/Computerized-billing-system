/* ***************************************
 * classGetchoice.cpp
 *****************************************/




#include "classGetchoice.h"

using std::cout;
using std::cin;
using std::string;
using std::vector;


classGetchoice::classGetchoice()
{
    //ctor
    totallen = new int;
    draw = new classDraw;
}

classGetchoice::~classGetchoice()
{
    //dtor
    delete totallen;
}

int classGetchoice::printMenu(vector<string> menu, string header)
{
    gotoxy(15, 2);
    cout << header;
    gotoxy(13, 3);
    int len = header.length();

    space = 13 + 3 + len;
    for(i = 13; i <= space; i++)
    {
        cout << "-";
    }
    l = 5;

    iter = menu.begin();
    while(iter != menu.end())
    {
        gotoxy(2, l);
        cout << *iter++;
        l++;
    }

    return l;
}

int classGetchoice::getChoice(vector<string> choices)
{
    mysql = classConn::connection();
    mysql->reconnect = true;

    int l = 0;
    int m = 0;


    drawRect();
    l = printMenu(choices, "MAIN MENU");
    gotoxy(15, ++l);
    do
    {
        gotoxy(15, l);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(int i = 15; i < w.ws_col - 1; i++)
        {
            cout << " ";
        }
        gotoxy(15, l);
        cout << "Enter Choice : ";
        getline(cin, strch);
        m = classValid::intvalidity(strch);
    }while(m < 1 || m > 13);

    return m;
}


















