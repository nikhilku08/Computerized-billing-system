/* ***************************************
 * classBill.cpp
 *****************************************/


#include "classBill.h"

using std::cin;
using std::cout;
using std::string;
using std::endl;

Vprd::Vprd()
{
    pid = 0;
    pname.clear();
    prate = 0;
    pquantity = 0;
    ptotal = 0;
}
Vprd::~Vprd() {}

classBill::classBill()
{
    //ctor

    salesmenu.push_back("Product ID : ");
    salesmenu.push_back("Product Name : ");
    salesmenu.push_back("stock : ");
    salesmenu.push_back("Rate : ");
    salesmenu.push_back("Quantity : ");
    salesmenu.push_back("Total : ");

    cnamevec.push_back("Customer Name : ");
    cnamevec.push_back("Address : ");
    cnamevec.push_back("Mobile No : ");

    vecBillmod.push_back("Bill : ");
    vecBillmod.push_back("Product ID : ");
    vecBillmod.push_back("Product Name : ");
    vecBillmod.push_back("Rate : ");
    vecBillmod.push_back("Quantity : ");
    vecBillmod.push_back("Total : ");
    vecBillmod.push_back("Customer name : ");
    vecBillmod.push_back("customer ID : ");
    vecBillmod.push_back("Date of sale : ");

    gtotal = 0;
    customerid = 0;

    draw = new classDraw;
    mysql = new MYSQL;
    totallen = new int;
    getc = new classGetchar;
    get = new classGetchoice;
    sqlp = new classSqlProcess;
    res = new MYSQL_RES;
    prd = new classProduct;
    customer = new classCustomer;
    vprd = new Vprd;

    i = 0;

    strmemno.clear();
}

classBill::~classBill()
{
    //dtor
    delete draw;
    delete mysql;
    delete res;
    delete totallen;
    delete sqlp;
    delete getc;
    delete get;
    delete prd;
}

int classBill::statbillno = 0;


void classBill::billing()
{
    int x = 31;
    draw->clrscr();
    draw->drawRect();

    mysql = classConn::connection();
    mysql->reconnect = true;

    l = get->printMenu(cnamevec, "Customer Details");

    do
    {
        draw->gotoxy(18, 5 );
        getline(cin, cname);
        flag = classValid::namevalidity(cname);
        if(flag == false)
        {
            cname.clear();
        }
        if(!cname.compare("q"))
        {
            return;
        }
    }while(cname.empty());
    cin.clear();
    do
    {
        draw->gotoxy(18, 6);
        getline(cin, strcaddress);
        if(!strcaddress.compare("q"))
        {
            return;
        }

    }while(strcaddress.empty());

    do
    {
        draw->gotoxy(18, 7);
        getline(cin, strmobileno);
        if(!strmobileno.compare("q"))
        {
            return;
        }
        mobileno = classValid::intvalidity(strmobileno);
        if(mobileno == 0)
        {
            strmobileno.clear();
        }
    }while(mobileno == 0);


    sql = "select max(billno) from tableBilling;";
    mysql = classConn::connection();

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            billno = std::stoi(row[0]);
        }
    }

    sql = "select max(billno) from tableCustomers;";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                int billno2 = std::stoi(row[0]);
                strbillno = row[0];
                if(billno2 > billno)
                {
                    sql = "delete from tableCustomers where billno = '"+strbillno+"';";
                    mysql = classConn::connection();
                    qstate = mysql_query(mysql, sql.c_str());
                    if(!qstate)
                    {
                        draw->gotoxy(2, 9);
                        cout << "duplicate entry for bill unique is deleted" ;
                        getc->getch();
                    }
                    else
                    {
                        draw->gotoxy(2, 9);
                        cout << "error in deleting duplicate bill in tableCusotmers : " << mysql_error(mysql);
                        getc->getch();
                    }
                }
            }
        }
        strbillno = std::to_string(++billno);
        mysql_free_result(res);
    }

    sql = "select max(id) from tableCustomers;";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                maxid = std::stoi(row[0]);
            }
            else
            {
                maxid = 0;
            }
        }
        strmaxid = std::to_string(++maxid);

        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(2, 11);
        cout << "Error in max(id) from tableCustomers : " << mysql_error(mysql);
        getc->getch();
        return;
    }

    sql = "insert into tableCustomers values('"+strmaxid+"','"+cname+"','"+strcaddress+"','"+strmobileno+"','"+strbillno+"');";

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        draw->gotoxy(2, 8);
        cout << "customers record inserted";
        getc->getch();
    }
    else
    {
        draw->gotoxy(2, 8);
        cout << "Error in insert into tableCustomers : " << mysql_error(mysql);
        getc->getch();
        return;
    }

LABEL1:
    do
    {
        draw->clrscr();
        draw->drawRect();
        gamount = 0;
        productid = prd->displayProduct("PRODUCT DISPALY AND BILLING");
        strprdid = std::to_string(productid);
        if(productid == 0)
        {
            return;
        }
        sql = "select productname from tableProductRecords where productid = '"+strprdid+"';";
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(2, 11);
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res)) == nullptr)
            {
                cout << "Invalid product selection or incorrect product id";
                getc->getch();
                productid = 0;
            }
            mysql_free_result(res);
        }
    }
    while(productid == 0);

    if(productid > 0)
    {
        draw->clrscr();
        draw->drawRect();
        get->printMenu(salesmenu, "Billing");
        draw->gotoxy(45, 3);
        cout << "Bill No. : " << strbillno;
        draw->gotoxy(31, 5);
        cout << productid;

        sql = "select productname, stock, rate from tableProductRecords where productid = '"+strprdid+"';";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res)) != nullptr)
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                draw->gotoxy(x, 6);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 6);
                strproductname = row[0];
                cout << strproductname;

                draw->gotoxy(x, 7);
                for(i = 31; i < w.ws_col-1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 7);
                stock = std::stoi(row[1]);
                cout << stock;

                draw->gotoxy(x, 8);
                for(i = 31; i < w.ws_col-1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 8);
                rate = std::stoi(row[2]);
                cout << rate;
            }
            mysql_free_result(res);
        }
        sql = "select p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b where b.billno = '"+
              strbillno+"' and productname in (select productname from tableProductRecords where productid =  b.productid);";

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(2, 17);
            cout << "Product Purchased";
            res = mysql_store_result(mysql);
            lines = sqlp->process_result_set(mysql, res, 20, totallen, 0);
            mysql_free_result(res);
        }
        else
        {
            draw->gotoxy(2, 18);
            cout << "Error in product purchased : " << mysql_error(mysql);
            getc->getch();
            return;
        }
        do
        {
            draw->gotoxy(x, 9);
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            for(i = x; i < w.ws_col - 1; i++)
            {
                cout << " ";
            }
            draw->gotoxy(x, 9);
            getline(cin, strquantity);
            if(!strquantity.compare("q"))
            {
                goto LABEL1;
            }
            if(!strquantity.empty())
            {
                quantity = classValid::intvalidity(strquantity);
                if(quantity == 0)
                {
                    draw->gotoxy(x, 9);
                    cout << "invalid quantity";
                    getc->getch();
                }
            }
            else
            {
                quantity = 0;
            }
        }while(quantity == 0);

        qty = stock - quantity;
        if(qty >= 0)
        {
            strqty = std::to_string(qty);
            total = quantity * rate;
            gtotal += total;
            draw->gotoxy(x, 10);
            cout << total;
        }
        else
        {
            draw->gotoxy(10, 12);
            cout << "Insufficient stock, available only : " << stock;
            getc->getch();
            goto LABEL1;
        }

        strstock = std::to_string(stock);
        strquantity = std::to_string(quantity);
        strrate = std::to_string(rate);
        strtotal = std::to_string(total);

        date *dt = new date;
        time_t now = time(0);
        tm *ltm = std::localtime(&now);
        dt->yy = ltm->tm_year;
        dt->mm = ltm->tm_mon + 1;
        dt->dd = ltm->tm_mday;

        strdate = std::to_string(1900 + dt->yy) + "/" + std::to_string(dt->mm) + "/" + std::to_string(dt->dd);

        draw->gotoxy(45, 4);
        cout << "Date  : " << strdate;

        sql = "select max(id) from tableBilling;";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res)) != nullptr)
            {
                if(row[0] == nullptr)
                {
                    maxid = 0;
                }
                else
                {
                    maxid = std::stoi(row[0]);
                }
                strmaxid = std::to_string(++maxid);
            }
            mysql_free_result(res);
        }
        else
        {
            draw->gotoxy(10, 13);
            cout << "error in max(id) billing : " << mysql_error(mysql);
            getc->getch();
        }

        sql = "select max(id) from tableCustomers";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res)) != nullptr)
            {
                if(row[0] == nullptr)
                {
                    customerid = 0;
                    draw->gotoxy(10, 13);
                    cout << "Error : Customer record not found please enter customer record"  ;
                    getc->getch();
                    return;
                }
                else
                {
                    customerid = std::stoi(row[0]);
                }
                strcustomerid = std::to_string(customerid);
            }
            mysql_free_result(res);
        }

        sql = "insert into tableBilling(id, productid, quantity, dateofsale, total, billno, customerid) values ('"+
              strmaxid+"','"+strprdid+"','"+strquantity+"','"+strdate+ "','"+strtotal+"', '"+strbillno+"','"+strcustomerid+"');";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(11, 11);
            cout << "Billing data inserted";

            sql = "select customername  from tableCustomers where billno = '"+strbillno+"';";
            mysql = classConn::connection();
            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                res = mysql_store_result(mysql);
                if((row = mysql_fetch_row(res)) != nullptr)
                {
                    strcname = row[0];
                    draw->gotoxy(2, 18);
                    cout << "Customer Name : "<< strcname;
                }
                mysql_free_result(res);
            }

            sql = "select p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b where b.billno = '"+
                  strbillno+"' and productname in (select productname from tableProductRecords where productid =  b.productid);";
            mysql = classConn::connection();
            qstate = mysql_query(mysql, sql.c_str());

            if(!qstate)
            {
                draw->gotoxy(1, 15);
                res = mysql_store_result(mysql);
                lines = sqlp->process_result_set(mysql, res, 20, totallen, 0);
                mysql_free_result(res);
            }
            else
            {
                draw->gotoxy(1, 15);
                cout << "Error in  billing data select : " << mysql_error(mysql);
                getc->getch();
            }
        }
        else
        {
            draw->gotoxy(1, 15);
            cout << "Error in insert into tableBilling  : " << mysql_error(mysql);
            getc->getch();
        }

        sql = "update tableProductRecords set stock  = '"+strqty+"' where productid = '"+strprdid+"';";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(x, 7);
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            for(int i = x; i < w.ws_col-1; i++)
            {
                cout<< " ";
            }

            draw->gotoxy(x, 7);
            cout << strqty;
            draw->gotoxy(11, 12);
            cout << "stock data updated successfully";
            getc->getch();
        }
        else
        {
            draw->gotoxy(1, 15);
            cout << "Error in update tableProductRecords : " << mysql_error(mysql);
            getc->getch();
        }
        sql = "select sum(total) from tableBilling where billno = '"+strbillno+"';";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res )) != nullptr)
            {
                if(row[0] != nullptr)
                {
                    gamount = std::stoi(row[0]);
                }
            }
            mysql_free_result(res);
        }
        else
        {
            draw->gotoxy(2, 25);
            cout << "Error in sum gamount : " << mysql_error(mysql);
        }
        draw->gotoxy(x, 13);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(i = x; i < w.ws_col - 1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(x, lines + 25);
        cout << "Grand Total : " << gamount;
    }
    do
    {
        draw->gotoxy(11,13);
        cout << "want to add more records : ";
        yesno = cin.get();
        if( (toupper(yesno) != 'Y' || toupper(yesno) != 'N') || int(yesno) == 10 )
        {
            draw->gotoxy(35, 13);
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            for(int x = 35; x < w.ws_col-1; x++)
            {
                cout << " ";
            }
            draw->gotoxy(35, 13);
        }
    }while(toupper(yesno) != 'Y' && toupper(yesno) != 'N');
    if(toupper(yesno) == 'Y')
    {
        getc->getch();
        goto LABEL1;
    }
    else if(toupper(yesno) == 'N')
    {
        return;
    }
}

void classBill::todaySales()
{
    mysql = classConn::connection();
    mysql->reconnect = true;

    draw->clrscr();
    draw->drawRect();

    draw->gotoxy(15, 3);

    cout << "Sales By Date";
    draw->gotoxy(13,4);
    cout << "-----------------";
    draw->gotoxy(10, 5);
    cout << "Enter Date to see sale : ( yyyy / MM/ dd ) : ";
    do
    {
        flag = true;
        draw->gotoxy(55, 5);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(int i = 55; i < w.ws_col -1; i++)
        {
            cout  << " ";
        }
        draw->gotoxy(55, 5);
        getline(cin,strdate);
        if(strdate.empty())
        {
            flag = true;
        }
        else
        {
            flag = classValid::isValidDate(strdate);
            if(!flag)
            {
                draw->gotoxy(10, 6);
                cout << "invalid date please re-enter";
                strdate.clear();
                getc->getch();
                draw->gotoxy(10, 6);
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

                for(int i = 10; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
            }
        }
    }while(flag == false);


    if(strdate.empty() == true)
    {
        date *dt = new date;
        time_t now = time(0);
        tm *ltm = std::localtime(&now);
        dt->yy = ltm->tm_year;
        dt->mm = ltm->tm_mon+1;
        dt->dd = ltm->tm_mday;

        strdate = std::to_string(1900 + dt->yy) + "/" + std::to_string(dt->mm) + "/" + std::to_string(dt->dd);
        draw->gotoxy(10, 6);
        cout << "date : " << strdate << endl;
    }
    else
    {
        draw->gotoxy(10, 6);
        cout << "date : " << strdate << endl;
    }

    mysql = classConn::connection();

    sql = "select distinct c.customername, c.contactaddress, c.mobileno, b.dateofsale, b.billno from tableCustomers as c, tableBilling as b  where ";
    sql += " c.billno = b.billno and b.dateofsale = '"+strdate+"' order by b.billno;";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        lines = sqlp->process_result_set(mysql, res, 7, totallen, 0);
        mysql_free_result(res);
        tlen1 = *totallen;
    }
    else
    {
        draw->gotoxy(2, lines + 10);
        cout << "Error in first sql in todaySales : " << mysql_error(mysql);
        getc->getch();
    }
    sql = "select p.productname, p.rate, b.quantity, b.total ,b.billno from tableProductRecords as p, tableBilling as b ";
    sql += "where b.dateofsale = '"+strdate+"' and p.productname in ( select productname from tableProductRecords where productid = b.productid )";
    sql += "order by b.billno;";

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        lines2 = sqlp->process_result_set(mysql, res, lines + 13, totallen, tlen1);
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(10, 7);
        cout << "Error in todays sale : " << mysql_error(mysql);
        getc->getch();
        return;
    }

    sql = "select sum(total) from  tableBilling  where dateofsale = '"+strdate+"';";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                gtotal = std::stoi(row[0]);
            }
            else
            {
                gtotal = 0;
            }
        }
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(10, lines + 25);
        cout << "Error in sum(total) : " << mysql_error(mysql);
        getc->getch();
    }

    draw->gotoxy(10 + *totallen, lines + 15 + lines2);
    cout << "Grand total : " << gtotal;

    getc->getch();
}

void classBill::modifyBill()
{
    draw->clrscr();
    draw->drawRect();

    int const x = 18;

    mysql = classConn::connection();
    mysql->reconnect = true;

    l = get->printMenu(vecBillmod, "Billing Modification");

    do
    {
        draw->gotoxy(x, 5);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(i = x; i <w.ws_col - 1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(x, 5);
        getline(cin, strbillno);
        if(!strbillno.compare("q"))
        {
            return;
        }
        if(!strbillno.compare("l"))
        {
            sql = "select max(billno) from tableBilling;";
            mysql = classConn::connection();
            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                res = mysql_store_result(mysql);
                if((row = mysql_fetch_row(res)) != nullptr)
                {
                    if(row[0] != nullptr)
                    {
                        strbillno = row[0];
                        billno = std::stoi(row[0]);
                    }
                }
                mysql_free_result(res);
            }
            draw->gotoxy(x, 5);
            cout << billno;
        }
        l = classValid::intvalidity(strbillno);
        if(l == 0)
        {
            draw->gotoxy(x, 5);
            cout << "Invalid Product ID please re-enter";
            strbillno.clear();
            getc->getch();
        }
    }while(strbillno.empty());

    sql = "select p.productid, p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b ";
    sql += "where b.billno ='"+strbillno+"' and p.productname in(select productname from tableProductRecords where ";
    sql += "productid = b.productid) order by p.productid;";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        res = mysql_store_result(mysql);
        lines = sqlp->process_result_set(mysql, res, 17, totallen, 0);
        len = *totallen;
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(2, 12);
        cout << "Error in sql like strbillno : " << mysql_error(mysql);
    }
    sql = "select customername, id from tableCustomers where billno = '"+strbillno+"';";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            if(row[0] != nullptr)
            {
                draw->gotoxy(x, 11);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 11);
                strcname = row[0];
                cout << strcname;
            }
            if(row[1] != nullptr)
            {
                draw->gotoxy(x, 12);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 12);
                strcustomerid = row[1];
                cout << strcustomerid;
            }
        }
        mysql_free_result(res);
    }

    sql = "select dateofsale from tableBilling where billno = '"+strbillno+"';";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res))!= nullptr)
        {
            if(row[0] != nullptr)
            {
                draw->gotoxy(x, 13);
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 13);
                strdate = row[0];
                cout << strdate;
            }
        }
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(2, 14);
        cout << "error in dateofsale : " << mysql_error(mysql);
        getc->getch();
    }

    draw->gotoxy(2, 14);
    cout << "Command : d for delete, a for add, q for return : ";
    do
    {
        draw->gotoxy(52, 14);
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        for(i = 52; i < w.ws_col - 1; i++)
        {
            cout <<" ";
        }
        draw->gotoxy(52, 14);
        getline(cin, strcmd);
        if(strcmd.compare("a") && strcmd.compare("d") && strcmd.compare("q"))
        {
            draw->gotoxy(52, 14);
            cout << "Invalid command";
            strcmd.clear();
            getc->getch();
        }
    }while(strcmd.compare("a") && strcmd.compare("d") && strcmd.compare("q"));

    if(!strcmd.compare("q"))
    {
        return;
    }
    else if(!strcmd.compare("a"))
    {
        draw->gotoxy(x, 6);

        int prdid = prd->displayProduct("Billing Modification");

        draw->clrscr();
        draw->drawRect();

        l = get->printMenu(vecBillmod, "Billing Modification");

        strprdid = std::to_string(prdid);

        vprdvec.clear();

        sql = "select p.productid, p.productname, p.rate from tableProductRecords as p ";
        sql += "where productid = '"+strprdid+"' order by p.productid;";

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            draw->clrscr(1, 17, w.ws_col - 1, w.ws_row - 1);
            draw->drawRect();

            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res))!= nullptr)
            {
                if(row[0] != nullptr)
                {
                    vp.pid = std::stoi(row[0]);
                }
                if(row[1] != nullptr)
                {
                    vp.pname = row[1];
                }
                if(row[2] != nullptr)
                {
                    vp.prate = std::stoi(row[2]);
                }
                vp.pquantity = 0;
                vp.ptotal = 0;
                vprdvec.push_back(vp);
            }
            mysql_free_result(res);
        }
        else
        {
            draw->gotoxy(2, 15);
            cout << "Error in vprdvec :" << mysql_error(mysql);
            getc->getch();
            return;
        }

        if(vprdvec.empty())
        {
            draw->gotoxy(2, 15);
            cout << "Product does not exists";
            getc->getch();
            return;
        }

        draw->gotoxy(x, 5);
        cout << strbillno;

        draw->gotoxy(x, 6);
        cout << vp.pid;

        draw->gotoxy(x, 7);
        cout <<  vp.pname;

        draw->gotoxy(x, 8);
        cout << vp.prate;

        draw->gotoxy(x, 11);
        cout << strcname;

        draw->gotoxy(x, 12);
        cout << strcustomerid;

        draw->gotoxy(x, 13);
        cout << strdate;

        do
        {
            ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
            draw->gotoxy(x, 9);
            for(i = x; i < w.ws_col - 1; i++)
            {
                cout << " ";
            }
            draw->gotoxy(x, 9);
            getline(cin, strquantity);
            if(!strquantity.compare("q"))
            {
                return;
            }
            vp.pquantity = classValid::intvalidity(strquantity);
            if(vp.pquantity == 0)
            {
                draw->gotoxy(x, 9);
                cout << "invalid quantity";
                strquantity.empty();
            }
        }while(strquantity.empty());

        vp.ptotal = vp.prate * vp.pquantity;

        draw->gotoxy(x, 10);
        cout << vp.ptotal;

        sql = "select max(id) from tableBilling";
        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            if((row = mysql_fetch_row(res)) != nullptr)
            {
                if(row[0] != nullptr)
                {
                    id = std::stoi(row[0]);
                }
                else
                {
                    id = 0;
                }
                strid = std::to_string(++id);
            }
            mysql_free_result(res);
        }

        strvpid = std::to_string(vp.pid);
        strquantity = std::to_string(vp.pquantity);
        strtotal = std::to_string(vp.ptotal);

        sql = "insert into tableBilling values('"+strid+"', '"+strvpid+"','"+strquantity+"','"
              +strdate+"', '"+strtotal+"','"+strbillno+"','"+strcustomerid+"');";

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            draw->gotoxy(2, 16);
            cout << "Data inserted successfully \n | Product Purchased :";
            getc->getch();
        }
        else
        {
            draw->gotoxy(2, lines + 25);
            cout << "error in insert into tableBilling : " << mysql_error(mysql);
            getc->getch();
        }

        sql = "select p.productid, p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b ";
        sql += "where b.billno ='"+strbillno+"' and p.productname in(select productname from tableProductRecords where ";
        sql += "productid = b.productid) order by p.productid;";

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            sqlp->process_result_set(mysql, res, 18, totallen, 0);
            getc->getch();
        }

        getc->getch();
    }
    else if(!strcmd.compare("d"))
    {
        vprdvec.clear();
        draw->gotoxy(x, 6);

        sql = "select p.productid, p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b ";
        sql += "where b.billno ='"+strbillno+"' and p.productname in(select productname from tableProductRecords where ";
        sql += "productid = b.productid) order by p.productid;";

        mysql = classConn::connection();
        qstate = mysql_query(mysql, sql.c_str());
        if(!qstate)
        {
            res = mysql_store_result(mysql);
            while((row = mysql_fetch_row(res))!= nullptr)
            {
                Vprd vp;
                if(row[0] != nullptr)
                {
                    vp.pid = std::stoi(row[0]);
                }
                if(row[1] != nullptr)
                {
                    vp.pname = row[1];
                }
                if(row[2] != nullptr)
                {
                    vp.prate = std::stoi(row[2]);
                }
                if(row[3] != nullptr)
                {
                    vp.pquantity = std::stoi(row[3]);
                }
                if(row[4] != nullptr)
                {
                    vp.ptotal = std::stoi(row[4]);
                }

                vprdvec.push_back(vp);
            }
            mysql_free_result(res);
        }
        else
        {
            draw->gotoxy(2, 15);
            cout << "Error in vprdvec :" << mysql_error(mysql);
            getc->getch();
            return;
        }

        if(vprdvec.empty())
        {
            draw->gotoxy(2, 15);
            cout << "Product does not exists";
            getc->getch();
            return;
        }

        for(vprditer = vprdvec.begin();; vprditer++)
        {
            escpch = getc->getch();
            if(vprditer == vprdvec.end())
            {
                vprditer = vprdvec.begin();
            }
            vp = *vprditer;
            if((int(escpch))  == 9)
            {
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);

                draw->gotoxy(x, 6);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }

                draw->gotoxy(x, 6);
                cout << vp.pid;
                strprdid = std::to_string(vp.pid);

                draw->gotoxy(x, 7);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }

                draw->gotoxy(x, 7);
                cout << vp.pname;

                draw->gotoxy(x, 8);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 8);
                cout << vp.prate;

                draw->gotoxy(x, 9);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 9);
                cout << vp.pquantity;

                draw->gotoxy(x, 10);
                for(i = x; i < w.ws_col - 1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 10);
                cout << vp.ptotal;
                draw->gotoxy(x, 6);
            }
            else if(int(escpch == 10))
            {
                draw->gotoxy(2, lines + 22);
                cout << "Really want to delete : ";
                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                do
                {
                    draw->gotoxy(27, lines + 22);
                    for(i = 27; i < w.ws_col - 1; i++)
                    {
                        cout << " ";
                    }
                    draw->gotoxy(27, lines + 22);
                    cin.get(yesno);
                }while(toupper(yesno) != 'Y' && toupper(yesno) != 'N' && toupper(yesno) != 'Q');
                if(toupper(yesno) == 'Q' || toupper(yesno) =='N')
                {
                    return;
                }
                else if(toupper(yesno) == 'Y')
                {
                    if(!strprdid.empty() && !strbillno.empty() && !strcustomerid.empty())
                    {
                        sql = "delete from tableBilling where productid = '"+strprdid+"'and billno = '"+
                               strbillno+"' and customerid = '"+strcustomerid+"';";
                        qstate =  mysql_query(mysql, sql.c_str());
                        if(!qstate)
                        {
                            draw->gotoxy(2, 15);
                            cout << "data has been deleted";
                            getc->getch();

                            sql = "select p.productid, p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b ";
                            sql += "where b.billno ='"+strbillno+"' and p.productname in(select productname from tableProductRecords where ";
                            sql += "productid = b.productid) order by p.productid;";

                            mysql = classConn::connection();
                            qstate = mysql_query(mysql, sql.c_str());
                            if(!qstate)
                            {
                                ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                                draw->clrscr(1, 17, w.ws_col - 1, w.ws_row - 1);
                                draw->drawRect();

                                res = mysql_store_result(mysql);
                                lines = sqlp->process_result_set(mysql, res, 17, totallen, 0);
                                mysql_free_result(res);
                                getc->getch();
                            }
                            if(lines == 0)
                            {
                                sql = "delete from tableCustomers where id = '"+strcustomerid+"';";
                                qstate = mysql_query(mysql, sql.c_str());
                                if(!qstate)
                                {
                                    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                                    for(i = 2; i < w.ws_col - 1; i++)
                                    {
                                        cout << " ";
                                    }
                                    draw->gotoxy(2, 15);
                                    cout << "Customer deleted from table";
                                    getc->getch();
                                }
                            }

                            sql = "select sum(total) from tableBilling where billno = '"+
                                   strbillno+"' and customerid = '"+strcustomerid+"';";
                            mysql = classConn::connection();
                            qstate = mysql_query(mysql, sql.c_str());
                            if(!qstate)
                            {
                                res = mysql_store_result(mysql);
                                if((row = mysql_fetch_row(res)) != nullptr)
                                {
                                    ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
                                    if(row[0] != nullptr)
                                    {
                                        draw->gotoxy(15, lines + 22);
                                        for(i = 15; i < w.ws_col -1; i++)
                                        {
                                            cout << " ";
                                        }
                                        draw->gotoxy(15, lines + 22);
                                        gtotal = std::stoi(row[0]);
                                        cout << "Grand Total : " <<  gtotal;
                                        getc->getch();
                                    }
                                }
                                mysql_free_result(res);
                            }
                            return;
                        }
                    }
                }
                else
                {
                    draw->gotoxy(2, 15);
                    cout << "strprdid or strbillno or strcustomerid is null";
                    getc->getch();
                }
            }
            else if(escpch == 'q')
            {
                return;
            }
        }
    }
}

void classBill::viewBill()
{

    mysql = classConn::connection();
    mysql->reconnect = true;

    int const x = 19;

    draw->clrscr();
    draw->drawRect();

    int l = get->printMenu(cnamevec, "Viewing Bill");

    draw->gotoxy(2, 4);
    cout << "Enter Bill No : ";
    do
    {
        ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
        draw->gotoxy(19, 4);
        for(i = 19; i < w.ws_col - 1; i++)
        {
            cout << " ";
        }
        draw->gotoxy(19, 4);
        getline(cin, strbillno);
        if(!strbillno.compare("q"))
        {
            return;
        }

        if(!strbillno.compare("l"))
        {
            sql = "select max(billno) from tableBilling;";
            mysql = classConn::connection();
            qstate = mysql_query(mysql, sql.c_str());
            if(!qstate)
            {
                res = mysql_store_result(mysql);
                if((row = mysql_fetch_row(res)) != nullptr)
                {
                    if(row[0] != nullptr)
                    {
                        strbillno = row[0];
                        billno = std::stoi(strbillno);
                        draw->gotoxy(x, 4);
                        cout << strbillno;
                    }
                }
                mysql_free_result(res);
            }
        }

        billno = classValid::intvalidity(strbillno);
        if(billno == 0)
        {
            strbillno.clear();
            draw->gotoxy(19, 4);
            cout << "invalid Bill number ";
            getc->getch();
        }
    }while(strbillno.empty());

    sql = "select customername, contactaddress, mobileno from tableCustomers where billno = '"+strbillno+"';";
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {

            if(row[0] != nullptr)
            {
                draw->gotoxy(x, 5);
                for(i = x; i < w.ws_col -1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 5);
                cout << row[0];
            }

            if(row[1] != nullptr)
            {
                draw->gotoxy(x, 6);
                for(i = x; i < w.ws_col -1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 6);
                cout << row[1];
            }

            if(row[2] != nullptr)
            {
                draw->gotoxy(x, 7);
                for(i = x; i < w.ws_col -1; i++)
                {
                    cout << " ";
                }
                draw->gotoxy(x, 7);
                cout << row[2];
            }
        }
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(2, 8);
        cout << "Error in select customer name : " << mysql_error(mysql);
        getc->getch();
    }

    sql = "select p.productid, p.productname, p.rate, b.quantity, b.total from tableProductRecords as p, tableBilling as b ";
    sql += "where b.billno ='"+strbillno+"' and p.productname in(select productname from tableProductRecords where ";
    sql += "productid = b.productid) order by p.productid;";

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        draw->clrscr(1, 10, w.ws_col -1 , w.ws_row -1 );
        draw->drawRect();
        lines = sqlp->process_result_set(mysql, res, 10, totallen, 0);
        mysql_free_result(res);
    }
    else
    {
        draw->gotoxy(2, lines + 20);
        cout << "Error in select of view : " << mysql_error(mysql);
        getc->getch();
    }

    sql = "select sum(total) from tableBilling where billno = '"+strbillno+"';";

    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                draw->gotoxy(10, lines + 15);
                cout << "Grant Total : " << row[0];
            }
        }
        mysql_free_result(res);
    }
    getc->getch();
}

void classBill::delEntry()
{
    sql = "select max(billno) from tableBilling;";
    mysql = classConn::connection();

    qstate = mysql_query(mysql, sql.c_str());
    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            billno = std::stoi(row[0]);
        }
    }

    sql = "select max(billno) from tableCustomers;";
    mysql = classConn::connection();
    qstate = mysql_query(mysql, sql.c_str());

    if(!qstate)
    {
        res = mysql_store_result(mysql);
        if((row = mysql_fetch_row(res)) != nullptr)
        {
            if(row[0] != nullptr)
            {
                int billno2 = std::stoi(row[0]);
                strbillno = row[0];
                if(billno2 > billno)
                {
                    sql = "delete from tableCustomers where billno = '"+strbillno+"';";
                    mysql = classConn::connection();
                    qstate = mysql_query(mysql, sql.c_str());
                    if(!qstate)
                    {
                        draw->gotoxy(2, 23);
                        cout << "duplicate entry for bill unique is deleted" ;
                        getc->getch();
                    }
                    else
                    {
                        draw->gotoxy(2, 23);
                        cout << "error in deleting duplicate bill in tableCustomers : " << mysql_error(mysql);
                        getc->getch();
                    }
                }
            }
        }
        mysql_free_result(res);
    }
}
































